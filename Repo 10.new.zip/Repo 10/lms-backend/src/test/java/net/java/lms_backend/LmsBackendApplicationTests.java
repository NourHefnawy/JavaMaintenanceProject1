package net.java.lms_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class LmsBackendApplicationTests {

	@Test
	void contextLoads() {

	}

}
