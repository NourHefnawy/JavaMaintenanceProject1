package net.java.lms_backend.entity;

public enum Role {
    USER,
    STUDENT,
    INSTRUCTOR,
    ADMIN
}
