package net.java.lms_backend.controller;

public @interface Inject {

}
