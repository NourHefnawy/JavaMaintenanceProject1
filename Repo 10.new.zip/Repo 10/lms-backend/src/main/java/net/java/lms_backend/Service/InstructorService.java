package net.java.lms_backend.Service;

public class InstructorService {
}
