package net.java.lms_backend.Repositrory;

public interface EmailSender {
    void send(String to, String email);
}