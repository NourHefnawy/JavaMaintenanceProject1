package net.java.lms_backend.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.multipart.MultipartFile;

import net.java.lms_backend.Service.CourseService;
import net.java.lms_backend.dto.Attendancedto;
import net.java.lms_backend.dto.Coursedto;
import net.java.lms_backend.dto.Enrollmentdto;
import net.java.lms_backend.dto.LessonDTO;
import net.java.lms_backend.dto.QuestionDTO;
import net.java.lms_backend.dto.StudentDTO;
import net.java.lms_backend.entity.Lesson;

@RestController
@RequestMapping("/api/courses")
public class CourseController {
    public final CourseService courseService;
    
    public CourseController(CourseService courseService){

        this.courseService=courseService;
        
    }
    @PostMapping
    public ResponseEntity<Coursedto> createCourse(@RequestBody Coursedto coursedto) {
        Coursedto newCourse=courseService.CreateCourse(coursedto);
        return new ResponseEntity<>(newCourse, HttpStatus.CREATED);
    }
    @PostMapping("/{courseId}/lessons")
    public ResponseEntity<Lesson> addLessonToCourse(@PathVariable Long courseId, @RequestBody LessonDTO lessonDTO) {
        Lesson lesson = new Lesson();
        lesson.setTitle(lessonDTO.getTitle());
        lesson.setContent(lessonDTO.getContent());
        Lesson savedLesson = courseService.addLessonToCourse(courseId, lesson);
        return new ResponseEntity<>(savedLesson, HttpStatus.CREATED);
    }
    @GetMapping("/instructor/{instructorId}")
    public ResponseEntity<List<Object>> getCoursesByInstructor(@PathVariable Long instructorId){
        List<Object> courses = courseService.getCoursesByInstructor(instructorId);
        return ResponseEntity.ok(courses);
    }
    @GetMapping("/{id}")
    public ResponseEntity<Coursedto> getCourseById(@PathVariable("id") Long id) {
        Coursedto course=courseService.getCourseById(id);
        return ResponseEntity.ok(course);
    }
    @DeleteMapping("/{id}")
    public ResponseEntity<Void>deleteCourse(@PathVariable Long id){
        courseService.deleteCourse(id);
        return ResponseEntity.noContent().build();
    }
    @PostMapping("/{id}/upload")
    public ResponseEntity<Void> uploadMediaFiles(
            @PathVariable Long id,
            @RequestParam("files") List<MultipartFile> files) {
        courseService.uploadMediaFiles(id, files);
        return ResponseEntity.ok().build();
    }
    @GetMapping("/available")
    public ResponseEntity<List<Object>> getAvailableCourses() {
        List<Object> courses = courseService.ViewAllCourse();
        return ResponseEntity.ok(courses);
    }

    @PostMapping("/{courseId}/enroll")
    public ResponseEntity<Void> enrollInCourse(@PathVariable Long courseId, @RequestBody Enrollmentdto enrollmentRequest) {
        courseService.enrollStudentInCourse(courseId, enrollmentRequest.getStudentId());
        return ResponseEntity.ok().build();
    }
    @GetMapping("/{courseId}/enrollments")
    public ResponseEntity<List<StudentDTO>> getEnrolledStudents(@PathVariable Long courseId) {
        List<StudentDTO> students = courseService.getEnrolledStudents(courseId);
        return ResponseEntity.ok(students);
    }
    @GetMapping("/api/resource/{id}")
    public ResponseEntity<String> getResourceById(@PathVariable Long id) { // Compliant
      return ResponseEntity.ok("Fetching resource with ID: " + id);
    }
    
    @GetMapping("/api/asset/{id}")
    public ResponseEntity<String> getAssetById(@PathVariable Long id, Object newParam) {
      return ResponseEntity.ok("Fetching asset with ID: " + id);
    }
    @GetMapping("/{courseId}/performance/{studentId}")
    public ResponseEntity<Integer> getPerformance(@PathVariable Long courseId, @PathVariable Long studentId) {
        int totalLessonsAttended = courseService.getPerformanceForStudent(studentId, courseId);
        return ResponseEntity.ok(totalLessonsAttended);
    }

    @GetMapping("/{courseId}/lessons/{lessonId}/attendance")
    public ResponseEntity<List<Attendancedto>> getAttendanceForLesson(@PathVariable Long courseId, @PathVariable Long lessonId) {
        List<Attendancedto> attendanceRecords = courseService.getAttendanceForLesson(lessonId);
        return ResponseEntity.ok(attendanceRecords);
    }


    @PostMapping("/{courseId}/add-questions")
    public ResponseEntity<Void> addQuestionsToCourse(@PathVariable Long courseId, @RequestBody List<QuestionDTO> questionDTOs) {
        courseService.addQuestionsToCourse(courseId, questionDTOs);
        return ResponseEntity.ok().build();
    }
    @GetMapping("/{courseId}/questions")
    public ResponseEntity<List<QuestionDTO>> getQuestionsByCourseId(@PathVariable Long courseId) {
        List<QuestionDTO> questions = courseService.getQuestionsByCourseId(courseId);
        return ResponseEntity.ok(questions);
    }

}