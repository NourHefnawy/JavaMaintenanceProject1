package net.java.lms_backend.entity;

import jakarta.persistence.Entity;
import net.java.lms_backend.dto.Coursedto;

@Entity
public class Admin extends User{
    public Admin(User user)
    {

        super(Role.ADMIN,new User());
    }
    public Admin()
    {
        super(Role.ADMIN,new User());
    }
    /**
     * @param course
     * @return
     */
    public static Coursedto mapToCoursedto(Course course) {
        throw new UnsupportedOperationException("Unimplemented method 'mapToCoursedto'");
    }
    /**
     * @param course
     * @return
     */
    public static Course maptoCourse(Course course) {
        throw new UnsupportedOperationException("Unimplemented method 'maptoCourse'");
    }
}
