package net.java.lms_backend.mapper;

import net.java.lms_backend.dto.Coursedto;
import net.java.lms_backend.entity.Course;

public class CourseMapper {
    /**
     * @param coursedto
     * @return
     */
    public static Course maptoCourse(Coursedto coursedto) {
        if(coursedto==null){
            throw new NullPointerException("The CourseDTO Should not be null");
        }
        Course course = new Course();
        course.setId(coursedto.getId());
        course.setTitle(coursedto.getTitle());
        course.setDescription(coursedto.getDescription());
        course.setDuration(coursedto.getDuration());
        course.setMediaFiles(coursedto.getMediaFiles());
        course.setInstructor(coursedto.getInstructor());
        return course;
    }

    @Override
    public String toString() {
        return "CourseMapper []";
    }

}